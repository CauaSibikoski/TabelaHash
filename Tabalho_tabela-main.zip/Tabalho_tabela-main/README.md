# Tabalho_tabela
Neste repositorio foi feito o processo do trabalho de arvore com tabela hash
